﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Evelin_Alim_Natadjaja
{
    public partial class BlinkShop : Form
    {
        DataTable dtProdukSimpan;
        DataTable dtProdukTampil;
        DataTable dtCategory;

        public BlinkShop()
        {
            InitializeComponent();
        }

        private void BlinkShop_Load(object sender, EventArgs e)
        {
            //kolom utk produk simpan
            dtProdukSimpan = new DataTable();
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");

            //baris utk product
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            //kolom untuk produk tampil
            dtProdukTampil = new DataTable();
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            //kolom utk category
            dtCategory = new DataTable();
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            //baris utk category
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");

            //data produk simpan dan category dimasukkan ke dgv
            dGV_Product.DataSource = dtProdukSimpan;
            dGV_Category.DataSource = dtCategory;

            //set ukuran kolom id dan nama
            dGV_Product.Columns[0].Width = 65;
            dGV_Product.Columns[1].Width = 100;

            //tambahin nama kategori di combo box filter dan detail
            cBox_Filter.Items.Add("Jas");
            cBox_Filter.Items.Add("T-Shirt");
            cBox_Filter.Items.Add("Rok");
            cBox_Filter.Items.Add("Celana");
            cBox_Filter.Items.Add("Cawat");

            cBox_CategoryDet.Items.Add("Jas");
            cBox_CategoryDet.Items.Add("T-Shirt");
            cBox_CategoryDet.Items.Add("Rok");
            cBox_CategoryDet.Items.Add("Celana");
            cBox_CategoryDet.Items.Add("Cawat");
        }

        private void BlinkShop_Shown(object sender, EventArgs e)
        {
            //supaya tidak ada row yang di selected
            dGV_Product.CurrentCell = null;
            dGV_Category.CurrentCell = null;
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            cBox_Filter.Enabled = true;
        }

        private void cBox_Filter_TextChanged(object sender, EventArgs e)
        {
            dtProdukTampil.Rows.Clear();

            //mengambil kode kategori dari nama yang dipilih
            string kodeCategoryTerpilih = string.Empty;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (cBox_Filter.Text.ToString() == dtCategory.Rows[i][1].ToString())
                {
                    kodeCategoryTerpilih = dtCategory.Rows[i][0].ToString();
                }
            }

            //menambahkan data produk yang sesuai dengan kode kategori
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (kodeCategoryTerpilih == dtProdukSimpan.Rows[i][4].ToString())
                {
                    dtProdukTampil.Rows.Add(dtProdukSimpan.Rows[i][0], dtProdukSimpan.Rows[i][1],
                        dtProdukSimpan.Rows[i][2], dtProdukSimpan.Rows[i][3], dtProdukSimpan.Rows[i][4]);
                }
            }

            dGV_Product.DataSource = dtProdukTampil;
            tB_NamaDet.Text = string.Empty;
            tB_HargaDet.Text = string.Empty;
            tB_StockDet.Text = string.Empty;
            cBox_CategoryDet.SelectedItem = null;
            dGV_Product.CurrentCell = null;
            dGV_Category.CurrentCell = null;
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            //menampilkan semua data
            cBox_Filter.SelectedItem = null;
            cBox_Filter.Enabled = false;
            dGV_Product.DataSource = dtProdukSimpan;
            Reset();
        }

        private void btn_AddPro_Click(object sender, EventArgs e)
        {
            //mengecek eror pada input
            if (tB_NamaDet.Text == string.Empty || tB_HargaDet.Text == string.Empty || tB_StockDet.Text == string.Empty)
            {
                MessageBox.Show("Ada Input yang Belum Terisi", "Error");
            }
            else if (cBox_CategoryDet.SelectedItem == null)
            {
                MessageBox.Show("Silahkan Pilih Category Terlebih Dahulu", "Error");
            }
            else
            {
                //mengambil huruf pertama dari nama produk untuk dijadikan id produk
                string hurufPertama = tB_NamaDet.Text.Substring(0, 1).ToUpper();

                //mengecek apakah pada dgv sudah ada nama dengan huruf pertama yang sama
                string idProduk;
                int idItemHurufSama = 0;
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][1].ToString().ToUpper().StartsWith(hurufPertama))
                    {
                        idItemHurufSama = i;
                    }
                }

                //mengambil nomor kode terakhir dari dgv
                int nomorId;
                if (idItemHurufSama == 0)
                {
                    nomorId = 1;
                }
                else
                {
                    nomorId = Convert.ToInt32(dtProdukSimpan.Rows[idItemHurufSama][0].ToString().Substring(1)) + 1;
                }

                //membuat id produk
                if (nomorId < 10)
                {
                    idProduk = hurufPertama.ToUpper() + "00" + nomorId;
                }
                else if (nomorId < 100 && nomorId >= 10)
                {
                    idProduk = hurufPertama.ToUpper() + "0" + nomorId;
                }
                else
                {
                    idProduk = hurufPertama.ToUpper() + nomorId;
                }

                //mengambil kode kategori dari nama kategori yang dipilih 
                string kodeCategory = string.Empty;
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (cBox_CategoryDet.Text.ToString() == dtCategory.Rows[i][1].ToString())
                    {
                        kodeCategory = dtCategory.Rows[i][0].ToString();
                    }
                }

                //menambahkan data
                dtProdukSimpan.Rows.Add(idProduk, tB_NamaDet.Text, tB_HargaDet.Text, tB_StockDet.Text, kodeCategory);
                Reset();
            }
        }

        private void tB_HargaDet_KeyPress(object sender, KeyPressEventArgs e)
        {
            //ketika key yg ditekan bukan angka atau control, baru bisa jalan
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tB_StockDet_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void dGV_Product_Click(object sender, EventArgs e)
        {
            //memasukkan row yang dipilih ke dalam textbox dan combo box details
            DataGridViewRow dgvr = dGV_Product.CurrentRow;
            tB_NamaDet.Text = dgvr.Cells[1].Value.ToString();
            tB_HargaDet.Text = dgvr.Cells[2].Value.ToString();
            tB_StockDet.Text = dgvr.Cells[3].Value.ToString();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dgvr.Cells[4].Value.ToString() == dtCategory.Rows[i][0].ToString())
                {
                    cBox_CategoryDet.SelectedItem = dtCategory.Rows[i][1].ToString();
                }
            }
        }

        private void btn_EditPro_Click(object sender, EventArgs e)
        {
            //cek apakah sudah ada baris yang dipilih
            if (dGV_Product.CurrentRow == null)
            {
                MessageBox.Show("Pilih Item yang Ingin Diedit", "Error");
            }
            else
            {
                //memasukkan hasil edit user ke dgv
                DataGridViewRow dgvr = dGV_Product.CurrentRow;
                dgvr.Cells[1].Value = tB_NamaDet.Text;
                dgvr.Cells[2].Value = tB_HargaDet.Text;

                //cek apakah ada stok yang 0 yang perlu dihapus
                if (tB_StockDet.Text == "0")
                {
                    dGV_Product.Rows.Remove(dgvr);
                }
                else
                {
                    dgvr.Cells[3].Value = tB_StockDet.Text;
                }

                //memasukkan kode category yang sesuai
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (cBox_CategoryDet.SelectedItem.ToString() == dtCategory.Rows[i][1].ToString())
                    {
                        dgvr.Cells[4].Value = dtCategory.Rows[i][0].ToString();
                    }
                }
            }
            Reset();
        }

        private void btn_RemovePro_Click(object sender, EventArgs e)
        {
            //cek apakah sudah memilih baris atau belum
            if (dGV_Product.CurrentCell != null)
            {
                DataGridViewRow dgvr = dGV_Product.CurrentRow;
                dGV_Product.Rows.Remove(dgvr);
            }
            Reset();
        }


        private void btn_AddCat_Click(object sender, EventArgs e)
        {
            if (tB_NamaCat.Text != string.Empty)
            {
                //cek id category
                int idCategory;
                if (dtCategory.Rows.Count == 0)
                {
                    idCategory = 0;
                }
                else
                {
                    idCategory = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1));
                }

                bool kembar = false;
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (tB_NamaCat.Text == dtCategory.Rows[i][1].ToString())
                    {
                        kembar = true;
                    }
                }
                if (kembar)
                {
                    MessageBox.Show("Kategori Sudah Tersedia Dalam Data", "Error");
                }
                else
                {
                    dtCategory.Rows.Add("C" + (idCategory + 1), tB_NamaCat.Text);
                    cBox_Filter.Items.Add(tB_NamaCat.Text);
                    cBox_CategoryDet.Items.Add(tB_NamaCat.Text);
                    Reset();
                }
            }
            else
            {
                MessageBox.Show("Mohon Masukkan Input Terlebih Dahulu", "Error");
            }
            dGV_Category.ClearSelection();
        }

        private void dGV_Category_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvr = dGV_Category.CurrentRow;
            tB_NamaCat.Text = dgvr.Cells[1].Value.ToString();
        }

        private void btn_RemoveCat_Click(object sender, EventArgs e)
        {
            if (dGV_Category.CurrentCell != null)
            {
                DataGridViewRow dgvrCat = dGV_Category.CurrentRow;
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][4].ToString() == dgvrCat.Cells[0].Value.ToString())
                    {
                        dtProdukSimpan.Rows.RemoveAt(i);
                        i--;
                    }
                }
                cBox_Filter.Items.Remove(tB_NamaCat.Text);
                cBox_CategoryDet.Items.Remove(tB_NamaCat.Text);
                dGV_Category.Rows.Remove(dgvrCat);
            }
            Reset();
        }

        void Reset()
        {
            tB_NamaCat.Text = string.Empty;
            tB_NamaDet.Text = string.Empty;
            tB_HargaDet.Text = string.Empty;
            tB_StockDet.Text = string.Empty;
            tB_NamaCat.Text = string.Empty;
            cBox_CategoryDet.SelectedItem = null;
            dGV_Product.CurrentCell = null;
            dGV_Category.CurrentCell = null;
        }
    }
}
