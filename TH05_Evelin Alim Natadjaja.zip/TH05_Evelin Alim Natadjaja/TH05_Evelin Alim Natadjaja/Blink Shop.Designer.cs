﻿namespace TH05_Evelin_Alim_Natadjaja
{
    partial class BlinkShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_AddPro = new System.Windows.Forms.Button();
            this.btn_EditPro = new System.Windows.Forms.Button();
            this.btn_AddCat = new System.Windows.Forms.Button();
            this.btn_RemovePro = new System.Windows.Forms.Button();
            this.btn_RemoveCat = new System.Windows.Forms.Button();
            this.tB_NamaCat = new System.Windows.Forms.TextBox();
            this.lb_NamaCat = new System.Windows.Forms.Label();
            this.cBox_CategoryDet = new System.Windows.Forms.ComboBox();
            this.tB_StockDet = new System.Windows.Forms.TextBox();
            this.tB_HargaDet = new System.Windows.Forms.TextBox();
            this.tB_NamaDet = new System.Windows.Forms.TextBox();
            this.lb_StockDet = new System.Windows.Forms.Label();
            this.lb_HargaDet = new System.Windows.Forms.Label();
            this.lb_CategoryDet = new System.Windows.Forms.Label();
            this.lb_NamaDet = new System.Windows.Forms.Label();
            this.cBox_Filter = new System.Windows.Forms.ComboBox();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.btn_All = new System.Windows.Forms.Button();
            this.dGV_Category = new System.Windows.Forms.DataGridView();
            this.dGV_Product = new System.Windows.Forms.DataGridView();
            this.lb_Details = new System.Windows.Forms.Label();
            this.lb_Category = new System.Windows.Forms.Label();
            this.lb_Product = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_Product)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_AddPro
            // 
            this.btn_AddPro.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_AddPro.Location = new System.Drawing.Point(193, 397);
            this.btn_AddPro.Name = "btn_AddPro";
            this.btn_AddPro.Size = new System.Drawing.Size(58, 41);
            this.btn_AddPro.TabIndex = 92;
            this.btn_AddPro.Text = "Add Product";
            this.btn_AddPro.UseVisualStyleBackColor = false;
            this.btn_AddPro.Click += new System.EventHandler(this.btn_AddPro_Click);
            // 
            // btn_EditPro
            // 
            this.btn_EditPro.BackColor = System.Drawing.Color.Yellow;
            this.btn_EditPro.Location = new System.Drawing.Point(252, 397);
            this.btn_EditPro.Name = "btn_EditPro";
            this.btn_EditPro.Size = new System.Drawing.Size(59, 41);
            this.btn_EditPro.TabIndex = 91;
            this.btn_EditPro.Text = "Edit Product";
            this.btn_EditPro.UseVisualStyleBackColor = false;
            this.btn_EditPro.Click += new System.EventHandler(this.btn_EditPro_Click);
            // 
            // btn_AddCat
            // 
            this.btn_AddCat.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_AddCat.Location = new System.Drawing.Point(472, 279);
            this.btn_AddCat.Name = "btn_AddCat";
            this.btn_AddCat.Size = new System.Drawing.Size(61, 41);
            this.btn_AddCat.TabIndex = 90;
            this.btn_AddCat.Text = "Add Category";
            this.btn_AddCat.UseVisualStyleBackColor = false;
            this.btn_AddCat.Click += new System.EventHandler(this.btn_AddCat_Click);
            // 
            // btn_RemovePro
            // 
            this.btn_RemovePro.BackColor = System.Drawing.Color.Red;
            this.btn_RemovePro.Location = new System.Drawing.Point(311, 397);
            this.btn_RemovePro.Name = "btn_RemovePro";
            this.btn_RemovePro.Size = new System.Drawing.Size(59, 41);
            this.btn_RemovePro.TabIndex = 89;
            this.btn_RemovePro.Text = "Remove Product";
            this.btn_RemovePro.UseVisualStyleBackColor = false;
            this.btn_RemovePro.Click += new System.EventHandler(this.btn_RemovePro_Click);
            // 
            // btn_RemoveCat
            // 
            this.btn_RemoveCat.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveCat.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_RemoveCat.Location = new System.Drawing.Point(539, 279);
            this.btn_RemoveCat.Name = "btn_RemoveCat";
            this.btn_RemoveCat.Size = new System.Drawing.Size(61, 41);
            this.btn_RemoveCat.TabIndex = 88;
            this.btn_RemoveCat.Text = "Remove Category";
            this.btn_RemoveCat.UseVisualStyleBackColor = false;
            this.btn_RemoveCat.Click += new System.EventHandler(this.btn_RemoveCat_Click);
            // 
            // tB_NamaCat
            // 
            this.tB_NamaCat.Location = new System.Drawing.Point(462, 253);
            this.tB_NamaCat.Name = "tB_NamaCat";
            this.tB_NamaCat.Size = new System.Drawing.Size(138, 20);
            this.tB_NamaCat.TabIndex = 87;
            // 
            // lb_NamaCat
            // 
            this.lb_NamaCat.AutoSize = true;
            this.lb_NamaCat.Location = new System.Drawing.Point(400, 256);
            this.lb_NamaCat.Name = "lb_NamaCat";
            this.lb_NamaCat.Size = new System.Drawing.Size(44, 13);
            this.lb_NamaCat.TabIndex = 86;
            this.lb_NamaCat.Text = "Nama : ";
            // 
            // cBox_CategoryDet
            // 
            this.cBox_CategoryDet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_CategoryDet.FormattingEnabled = true;
            this.cBox_CategoryDet.Location = new System.Drawing.Point(81, 373);
            this.cBox_CategoryDet.Name = "cBox_CategoryDet";
            this.cBox_CategoryDet.Size = new System.Drawing.Size(99, 21);
            this.cBox_CategoryDet.TabIndex = 85;
            // 
            // tB_StockDet
            // 
            this.tB_StockDet.Location = new System.Drawing.Point(81, 422);
            this.tB_StockDet.Name = "tB_StockDet";
            this.tB_StockDet.Size = new System.Drawing.Size(99, 20);
            this.tB_StockDet.TabIndex = 84;
            this.tB_StockDet.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tB_StockDet_KeyPress);
            // 
            // tB_HargaDet
            // 
            this.tB_HargaDet.Location = new System.Drawing.Point(81, 398);
            this.tB_HargaDet.Name = "tB_HargaDet";
            this.tB_HargaDet.Size = new System.Drawing.Size(99, 20);
            this.tB_HargaDet.TabIndex = 83;
            this.tB_HargaDet.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tB_HargaDet_KeyPress);
            // 
            // tB_NamaDet
            // 
            this.tB_NamaDet.Location = new System.Drawing.Point(81, 348);
            this.tB_NamaDet.Name = "tB_NamaDet";
            this.tB_NamaDet.Size = new System.Drawing.Size(289, 20);
            this.tB_NamaDet.TabIndex = 82;
            // 
            // lb_StockDet
            // 
            this.lb_StockDet.AutoSize = true;
            this.lb_StockDet.Location = new System.Drawing.Point(30, 425);
            this.lb_StockDet.Name = "lb_StockDet";
            this.lb_StockDet.Size = new System.Drawing.Size(44, 13);
            this.lb_StockDet.TabIndex = 81;
            this.lb_StockDet.Text = "Stock : ";
            // 
            // lb_HargaDet
            // 
            this.lb_HargaDet.AutoSize = true;
            this.lb_HargaDet.Location = new System.Drawing.Point(30, 401);
            this.lb_HargaDet.Name = "lb_HargaDet";
            this.lb_HargaDet.Size = new System.Drawing.Size(42, 13);
            this.lb_HargaDet.TabIndex = 80;
            this.lb_HargaDet.Text = "Harga :";
            // 
            // lb_CategoryDet
            // 
            this.lb_CategoryDet.AutoSize = true;
            this.lb_CategoryDet.Location = new System.Drawing.Point(17, 376);
            this.lb_CategoryDet.Name = "lb_CategoryDet";
            this.lb_CategoryDet.Size = new System.Drawing.Size(58, 13);
            this.lb_CategoryDet.TabIndex = 79;
            this.lb_CategoryDet.Text = "Category : ";
            // 
            // lb_NamaDet
            // 
            this.lb_NamaDet.AutoSize = true;
            this.lb_NamaDet.Location = new System.Drawing.Point(31, 351);
            this.lb_NamaDet.Name = "lb_NamaDet";
            this.lb_NamaDet.Size = new System.Drawing.Size(44, 13);
            this.lb_NamaDet.TabIndex = 78;
            this.lb_NamaDet.Text = "Nama : ";
            // 
            // cBox_Filter
            // 
            this.cBox_Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_Filter.Enabled = false;
            this.cBox_Filter.FormattingEnabled = true;
            this.cBox_Filter.Location = new System.Drawing.Point(278, 46);
            this.cBox_Filter.Name = "cBox_Filter";
            this.cBox_Filter.Size = new System.Drawing.Size(91, 21);
            this.cBox_Filter.TabIndex = 77;
            this.cBox_Filter.TextChanged += new System.EventHandler(this.cBox_Filter_TextChanged);
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(231, 44);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(41, 23);
            this.btn_Filter.TabIndex = 76;
            this.btn_Filter.Text = "Filter:";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(184, 44);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(41, 23);
            this.btn_All.TabIndex = 75;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // dGV_Category
            // 
            this.dGV_Category.AllowUserToAddRows = false;
            this.dGV_Category.AllowUserToDeleteRows = false;
            this.dGV_Category.AllowUserToResizeColumns = false;
            this.dGV_Category.AllowUserToResizeRows = false;
            this.dGV_Category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGV_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_Category.Location = new System.Drawing.Point(403, 73);
            this.dGV_Category.MultiSelect = false;
            this.dGV_Category.Name = "dGV_Category";
            this.dGV_Category.ReadOnly = true;
            this.dGV_Category.RowHeadersVisible = false;
            this.dGV_Category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGV_Category.Size = new System.Drawing.Size(197, 164);
            this.dGV_Category.TabIndex = 74;
            this.dGV_Category.Click += new System.EventHandler(this.dGV_Category_Click);
            // 
            // dGV_Product
            // 
            this.dGV_Product.AllowUserToAddRows = false;
            this.dGV_Product.AllowUserToDeleteRows = false;
            this.dGV_Product.AllowUserToResizeColumns = false;
            this.dGV_Product.AllowUserToResizeRows = false;
            this.dGV_Product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGV_Product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dGV_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_Product.Location = new System.Drawing.Point(33, 73);
            this.dGV_Product.MultiSelect = false;
            this.dGV_Product.Name = "dGV_Product";
            this.dGV_Product.ReadOnly = true;
            this.dGV_Product.RowHeadersVisible = false;
            this.dGV_Product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGV_Product.Size = new System.Drawing.Size(337, 219);
            this.dGV_Product.TabIndex = 73;
            this.dGV_Product.Click += new System.EventHandler(this.dGV_Product_Click);
            // 
            // lb_Details
            // 
            this.lb_Details.AutoSize = true;
            this.lb_Details.BackColor = System.Drawing.Color.PeachPuff;
            this.lb_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Details.Location = new System.Drawing.Point(30, 314);
            this.lb_Details.Name = "lb_Details";
            this.lb_Details.Size = new System.Drawing.Size(65, 20);
            this.lb_Details.TabIndex = 72;
            this.lb_Details.Text = "Details";
            // 
            // lb_Category
            // 
            this.lb_Category.AutoSize = true;
            this.lb_Category.BackColor = System.Drawing.Color.PeachPuff;
            this.lb_Category.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Category.Location = new System.Drawing.Point(399, 28);
            this.lb_Category.Name = "lb_Category";
            this.lb_Category.Size = new System.Drawing.Size(81, 20);
            this.lb_Category.TabIndex = 71;
            this.lb_Category.Text = "Category";
            // 
            // lb_Product
            // 
            this.lb_Product.AutoSize = true;
            this.lb_Product.BackColor = System.Drawing.Color.PeachPuff;
            this.lb_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Product.Location = new System.Drawing.Point(30, 28);
            this.lb_Product.Name = "lb_Product";
            this.lb_Product.Size = new System.Drawing.Size(71, 20);
            this.lb_Product.TabIndex = 70;
            this.lb_Product.Text = "Product";
            // 
            // BlinkShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Salmon;
            this.ClientSize = new System.Drawing.Size(617, 470);
            this.Controls.Add(this.btn_AddPro);
            this.Controls.Add(this.btn_EditPro);
            this.Controls.Add(this.btn_AddCat);
            this.Controls.Add(this.btn_RemovePro);
            this.Controls.Add(this.btn_RemoveCat);
            this.Controls.Add(this.tB_NamaCat);
            this.Controls.Add(this.lb_NamaCat);
            this.Controls.Add(this.cBox_CategoryDet);
            this.Controls.Add(this.tB_StockDet);
            this.Controls.Add(this.tB_HargaDet);
            this.Controls.Add(this.tB_NamaDet);
            this.Controls.Add(this.lb_StockDet);
            this.Controls.Add(this.lb_HargaDet);
            this.Controls.Add(this.lb_CategoryDet);
            this.Controls.Add(this.lb_NamaDet);
            this.Controls.Add(this.cBox_Filter);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.dGV_Category);
            this.Controls.Add(this.dGV_Product);
            this.Controls.Add(this.lb_Details);
            this.Controls.Add(this.lb_Category);
            this.Controls.Add(this.lb_Product);
            this.Name = "BlinkShop";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.BlinkShop_Load);
            this.Shown += new System.EventHandler(this.BlinkShop_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dGV_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_Product)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_AddPro;
        private System.Windows.Forms.Button btn_EditPro;
        private System.Windows.Forms.Button btn_AddCat;
        private System.Windows.Forms.Button btn_RemovePro;
        private System.Windows.Forms.Button btn_RemoveCat;
        private System.Windows.Forms.TextBox tB_NamaCat;
        private System.Windows.Forms.Label lb_NamaCat;
        private System.Windows.Forms.ComboBox cBox_CategoryDet;
        private System.Windows.Forms.TextBox tB_StockDet;
        private System.Windows.Forms.TextBox tB_HargaDet;
        private System.Windows.Forms.TextBox tB_NamaDet;
        private System.Windows.Forms.Label lb_StockDet;
        private System.Windows.Forms.Label lb_HargaDet;
        private System.Windows.Forms.Label lb_CategoryDet;
        private System.Windows.Forms.Label lb_NamaDet;
        private System.Windows.Forms.ComboBox cBox_Filter;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.DataGridView dGV_Category;
        private System.Windows.Forms.DataGridView dGV_Product;
        private System.Windows.Forms.Label lb_Details;
        private System.Windows.Forms.Label lb_Category;
        private System.Windows.Forms.Label lb_Product;
    }
}

